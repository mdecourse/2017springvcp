import pygame
# 載入圖檔
skier= pygame.image.load('skier_down.png')
skier2= pygame.image.load('skier_crash.png')
# 設定影幕尺寸
screen = pygame.display.set_mode((800, 600))
# 填入白色
screen.fill([255, 255, 255])
# 設定時間追蹤物件
clock = pygame.time.Clock()
# 在螢幕中特定位置畫出 skier
screen.blit(skier, (50, 100))
screen.blit(skier2, (100, 100))
screen.blit(skier2, (200, 100))
# 準備執行迴圈
running = True
while running:
    clock.tick(30)
    for event in pygame.event.get():
        if event.type == pygame.QUIT: 
            running = False
    pygame.display.flip()

