"""
AI Name: Null AI

Made by: Carter

Strategy:
Do nothing.
"""


class AI:
    def turn(self):
        self.robot.doNothing()